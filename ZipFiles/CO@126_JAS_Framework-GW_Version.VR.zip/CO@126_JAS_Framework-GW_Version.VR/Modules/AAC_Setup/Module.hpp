#include "scriptComponent.hpp"

#ifdef LOAD_MODULES
	class COMPONENT: GW_Modules_Base {
		name = COMPONENT;
		Authors[] = {"Jason"};
		version = 1.4;
		description = "Handles automatic spawning of AAC equipment to assist editors";
	};
#endif
