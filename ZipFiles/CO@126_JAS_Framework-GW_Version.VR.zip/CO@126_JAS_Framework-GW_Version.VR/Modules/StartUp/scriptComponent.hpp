#define	COMPONENT StartUp
#include "..\scriptComponent.hpp"
