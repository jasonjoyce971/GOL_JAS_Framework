//	#define DEBUG_MODE_FULL
#define	COMPONENT setDifficulty
#include "..\scriptComponent.hpp"
