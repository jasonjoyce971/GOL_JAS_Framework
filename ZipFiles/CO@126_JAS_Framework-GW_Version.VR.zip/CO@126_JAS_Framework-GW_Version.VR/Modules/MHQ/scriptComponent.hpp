#define	COMPONENT MHQ
#include "..\scriptComponent.hpp"
