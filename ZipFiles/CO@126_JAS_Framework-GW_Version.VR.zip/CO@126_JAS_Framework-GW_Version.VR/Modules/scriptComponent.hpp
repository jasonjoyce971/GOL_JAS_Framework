
#ifndef CUSTOM_FOLDER
	#define CUSTOM_FOLDER Modules\COMPONENT\Functions
#endif

#include "..\scriptComponent.hpp"
