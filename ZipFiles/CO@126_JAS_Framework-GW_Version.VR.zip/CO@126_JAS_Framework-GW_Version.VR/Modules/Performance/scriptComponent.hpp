#define	COMPONENT Performance
#include "..\scriptComponent.hpp"
