#define DEBUG_MODE_FULL
#define	COMPONENT Settings_ACE
#include "..\scriptComponent.hpp"
