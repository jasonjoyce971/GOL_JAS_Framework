
class Actions {
	class MiscRepair {
		items[] = {};
		itemConsumed = 0;
	};
	class FullRepair {
		itemConsumed = 0;
	};
};
