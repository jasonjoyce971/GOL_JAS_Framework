#include "scriptComponent.hpp"

#ifdef LOAD_MODULES
	class COMPONENT: GW_Modules_Base {
		name = COMPONENT;
		Authors[] = {"NeKo-Arrow","GuzzenVonLidl"};
		version = 3;
		description = "NeKo-Arrow's ServiceStation | Date: 20/05/17";
		postInit = "";
	};
#endif
