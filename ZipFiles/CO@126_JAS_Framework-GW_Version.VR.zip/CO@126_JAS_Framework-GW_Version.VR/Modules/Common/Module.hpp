#include "scriptComponent.hpp"

#ifdef LOAD_MODULES
	class COMPONENT: GW_Modules_Base {
		name = COMPONENT;
		Authors[] = {"GuzzenVonLidl"};
		version = 1.5;
		description = "Common Function used through out the framework";
	};
#endif
