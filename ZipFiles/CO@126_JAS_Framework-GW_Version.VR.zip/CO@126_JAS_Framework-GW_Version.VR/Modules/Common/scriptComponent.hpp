//#define DEBUG_MODE_FULL
#define	COMPONENT Common
#include "..\scriptComponent.hpp"
