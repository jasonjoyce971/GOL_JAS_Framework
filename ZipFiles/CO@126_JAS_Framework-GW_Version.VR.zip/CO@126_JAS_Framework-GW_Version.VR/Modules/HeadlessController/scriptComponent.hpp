#define	COMPONENT HeadlessController
#include "..\scriptComponent.hpp"
