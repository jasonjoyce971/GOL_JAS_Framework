#define	COMPONENT Radios
#include "..\scriptComponent.hpp"
