//ISNILS(Does variable exist, If not use this variable);

ISNILS(_rifleC,_rifle);
ISNILS(_rifleGL,_rifle);
ISNILS(_rifleMarksman,_rifle);
ISNILS(_LMG,_rifle);
ISNILS(_MMG,_LMG);
ISNILS(_MAT,_LAT);

ISNILS(_pistol_mag_tr,_pistol_mag);

ISNILS(_rifle_mag_tr,_rifle_mag);
ISNILS(_rifleC_mag,_rifle_mag);
ISNILS(_rifleC_mag_tr,_rifle_mag_tr);
ISNILS(_rifleGL_mag,_rifle_mag);
ISNILS(_rifleGL_mag_tr,_rifle_mag_tr);
ISNILS(_rifleMarksman_mag,_rifle_mag);
ISNILS(_rifleMarksman_mag_tr,_rifle_mag_tr);
ISNILS(_LMG_mag_tr,_LMG_mag);
ISNILS(_MMG_mag,_LMG_mag);
ISNILS(_MMG_mag_tr,_LMG_mag_tr);

ISNILS(_LAT_mag_HE,_LAT_mag);
ISNILS(_MAT_mag,_LAT_mag);
ISNILS(_MAT_mag_HE,_MAT_mag);
