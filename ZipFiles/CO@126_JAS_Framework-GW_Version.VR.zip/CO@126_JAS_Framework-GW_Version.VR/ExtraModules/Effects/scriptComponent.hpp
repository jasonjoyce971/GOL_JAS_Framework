#define	COMPONENT Effects
#include "..\scriptComponent.hpp"
