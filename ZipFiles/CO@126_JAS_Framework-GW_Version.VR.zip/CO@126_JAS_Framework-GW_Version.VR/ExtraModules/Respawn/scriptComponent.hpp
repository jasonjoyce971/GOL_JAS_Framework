#define	COMPONENT Respawn
#include "..\scriptComponent.hpp"
