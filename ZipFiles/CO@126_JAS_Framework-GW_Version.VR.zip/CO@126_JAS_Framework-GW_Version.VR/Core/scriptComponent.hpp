//#define DEBUG_MODE_FULL
#define	COMPONENT CORE
#define VERSION 1
#define CUSTOM_FOLDER Core\Functions

#include "..\scriptComponent.hpp"
