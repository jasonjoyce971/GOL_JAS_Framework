#define	COMPONENT ServiceStation
#include "..\script_Component.hpp"
