//#define DEBUG_MODE_FULL
#define	COMPONENT Common
#include "..\script_Component.hpp"
