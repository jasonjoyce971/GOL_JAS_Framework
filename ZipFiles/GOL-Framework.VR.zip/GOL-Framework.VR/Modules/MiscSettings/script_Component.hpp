#define	COMPONENT MiscSettings
#include "..\script_Component.hpp"
