#include "script_Component.hpp"

#ifdef LOAD_MODULES
	class COMPONENT: GW_Modules_Base {
		name = COMPONENT;
		Authors[] = {"GuzzenVonLidl"};
		version = 1;			// Current version of this module, used to keep track of every update for all mission makers
		description = "Description of this module";
	};
#endif
