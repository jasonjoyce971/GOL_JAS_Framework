#define	COMPONENT StartUp
#include "..\script_Component.hpp"
