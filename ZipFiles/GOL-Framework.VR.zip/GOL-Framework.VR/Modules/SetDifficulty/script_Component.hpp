//	#define DEBUG_MODE_FULL
#define	COMPONENT setDifficulty
#include "..\script_Component.hpp"
