#define	COMPONENT MHQ
#include "..\script_Component.hpp"
