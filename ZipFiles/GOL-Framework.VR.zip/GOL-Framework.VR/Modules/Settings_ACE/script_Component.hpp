#define DEBUG_MODE_FULL
#define	COMPONENT Settings_ACE
#include "..\script_Component.hpp"
