
#ifndef CUSTOM_FOLDER
	#define CUSTOM_FOLDER Modules\COMPONENT\Functions
#endif

#include "..\script_Component.hpp"
