#define	COMPONENT Effects
#include "..\script_Component.hpp"
