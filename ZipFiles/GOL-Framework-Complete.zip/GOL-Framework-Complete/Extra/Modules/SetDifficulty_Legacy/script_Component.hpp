//	#define DEBUG_MODE_FULL
#define	COMPONENT SetDifficulty_Legacy
#include "..\script_Component.hpp"
