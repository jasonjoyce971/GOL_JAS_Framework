#define	COMPONENT HeadlessController
#include "..\script_Component.hpp"
