#define DEBUG_MODE_FULL	// Enables debug mode for the component
#define	COMPONENT Example
#include "..\scriptComponent.hpp"