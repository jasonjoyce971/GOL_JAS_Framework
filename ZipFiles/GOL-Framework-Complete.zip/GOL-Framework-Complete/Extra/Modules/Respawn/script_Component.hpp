#define	COMPONENT Respawn
#include "..\script_Component.hpp"
