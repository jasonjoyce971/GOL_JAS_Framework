#include "script_Component.hpp"

#ifdef LOAD_MODULES
	class COMPONENT: GW_Modules_Base {
		name = COMPONENT;
		Authors[] = {"NeKo-Arrow","GuzzenVonLidl"};
		version = 3;
		description = "NeKo-Arrow's ServiceStation | Date: 25/07/17";
		postInit = "";
	};
#endif
