#define	COMPONENT Radios
#include "..\script_Component.hpp"
