
	class Framework_Core {
		file = "Core\Framework\Functions";
		class AudioDetectorAI{};
		class DebugLog {};
		class GetConfig {};
		class HeadlessClient{};
		class Players {};
		class RemoteExecuterHC{};
		class Roster{};
	};
