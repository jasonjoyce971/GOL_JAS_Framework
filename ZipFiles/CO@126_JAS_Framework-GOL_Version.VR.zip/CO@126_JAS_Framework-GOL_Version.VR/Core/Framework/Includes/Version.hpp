// *	Framework Information

		GOL_Author = "GOL Editing Team";
		GOL_Version = "0.80";
		GOL_Teamspeak = "teamspeak.gol-clan.co.uk";
		GOL_url = "http://www.gol-clan.co.uk/";

		publicVariable "GOL_Author";
		publicVariable "GOL_Version";
		publicVariable "GOL_Teamspeak";
		publicVariable "GOL_url";
