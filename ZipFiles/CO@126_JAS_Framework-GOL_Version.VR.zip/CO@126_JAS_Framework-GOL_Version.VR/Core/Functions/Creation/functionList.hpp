
	class Creation {
		file = "Core\Functions\Creation";
		class CopyAIEdenZeus{};
		class CopyLocation{};
		class CopyObjects{};
		class CreateAIStatic{};
		class CreateAIStaticAutoGroup{};
		class CreateObjects{};
	};
