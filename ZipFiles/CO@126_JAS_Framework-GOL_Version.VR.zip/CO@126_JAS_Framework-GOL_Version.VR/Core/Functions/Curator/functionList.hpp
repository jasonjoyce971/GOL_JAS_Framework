
	class Zeus {
		file = "Core\Functions\Curator";
		class Curator_Setskill{};
		class Curator_AddPlayers{};
		class Curator_Units{};
	};
