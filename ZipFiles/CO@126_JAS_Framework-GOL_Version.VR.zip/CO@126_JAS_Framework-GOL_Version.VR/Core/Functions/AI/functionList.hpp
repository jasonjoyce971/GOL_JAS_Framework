
	class AI_Spawning {
		file = "Core\Functions\AI";
		class AI_Inf_Group{};
		class AI_Vehicle{};
		class BuildingPop{};
		class EnemyFactions{};
	};
