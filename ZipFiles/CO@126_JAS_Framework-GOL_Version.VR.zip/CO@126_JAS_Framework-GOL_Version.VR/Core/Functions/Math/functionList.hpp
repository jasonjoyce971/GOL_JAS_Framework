
	class Math {
		file = "Core\Functions\Math";
		class GetPos{};
		class GetSide{};
		class paramDaytime{};
		class setDirFly{};
		class Teleport{};
	};
