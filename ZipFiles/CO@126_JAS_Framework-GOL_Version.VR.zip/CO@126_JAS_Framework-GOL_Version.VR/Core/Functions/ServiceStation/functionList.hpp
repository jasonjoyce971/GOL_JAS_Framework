
	class ServiceStation {
		file = "Core\Functions\ServiceStation";
		class ServiceStation{};
		class ServiceStation_FullService{};
		class ServiceStation_Lights{};
		class ServiceStation_OTM{};
		class ServiceStation_Rearm{};
		class ServiceStation_Refuel{};
		class ServiceStation_Repair{};
	};
