
	class Misc {
		file = "Core\Functions\Misc";
//		class FPS_Manager{ ext = ".fsm"; };
		class MHQ{};
		class MHQActions{};
	};
