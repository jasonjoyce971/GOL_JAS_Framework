
	class Gear_Handlers {
		file = "Gear";
		class GearCargo{};
		class GearHandler{};
	};
	#include "Factions\Functions\functionList.hpp"