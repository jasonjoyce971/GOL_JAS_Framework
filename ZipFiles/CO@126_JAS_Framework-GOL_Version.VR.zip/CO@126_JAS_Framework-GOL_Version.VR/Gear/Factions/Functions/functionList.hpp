
	class Gear_Basic {
		file = "Gear\Factions\Functions";
//		class AddItemCargo{};
//		class AddMagazineCargo{};
		class AddObjects{};
		class AddObjectsCargo{};
		class AddObjectsToBackpack{};
//		class AddWeaponCargo{};
		class Attachments{};
	};